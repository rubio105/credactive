import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import { HelmetProvider } from 'react-helmet-async';
import CookieBanner from "@/components/cookie-banner";
import { FeedbackDialog } from "@/components/FeedbackDialog";
import Landing from "@/pages/landing";
import Home from "@/pages/home";
import Quiz from "@/pages/quiz";
import Dashboard from "@/pages/dashboard";
import Subscribe from "@/pages/subscribe";
import Report from "@/pages/report";
import Admin from "@/pages/admin";
import ChiSiamo from "@/pages/chi-siamo";
import Contatti from "@/pages/contatti";
import DynamicContentPage from "@/pages/DynamicContentPage";
import Login from "@/pages/login";
import Register from "@/pages/register";
import VerifyEmail from "@/pages/verify-email";
import ForgotPassword from "@/pages/forgot-password";
import ResetPassword from "@/pages/reset-password";
import Logout from "@/pages/logout";
import NotFound from "@/pages/not-found";
import CorsiOnDemand from "@/pages/corsi-on-demand";
import CorsoOnDemand from "@/pages/corso-on-demand";
import Settings from "@/pages/settings";
import Leaderboard from "@/pages/leaderboard";
import Certificates from "@/pages/certificates";
import Analytics from "@/pages/analytics";
import CorporatePortal from "@/pages/corporate-portal";
import CorporateJoin from "@/pages/corporate-join";
import LiveSession from "@/pages/live-session";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <Switch>
      <Route path="/chi-siamo" component={ChiSiamo} />
      <Route path="/contatti" component={Contatti} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/verify-email" component={VerifyEmail} />
      <Route path="/forgot-password" component={ForgotPassword} />
      <Route path="/reset-password" component={ResetPassword} />
      <Route path="/logout" component={Logout} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/subscribe" component={Subscribe} />
      <Route path="/settings" component={Settings} />
      <Route path="/leaderboard" component={Leaderboard} />
      <Route path="/certificates" component={Certificates} />
      <Route path="/analytics" component={Analytics} />
      <Route path="/admin" component={Admin} />
      <Route path="/corporate" component={CorporatePortal} />
      <Route path="/corporate/join/:token" component={CorporateJoin} />
      {isLoading || !isAuthenticated ? (
        <Route path="/" component={Landing} />
      ) : (
        <>
          <Route path="/" component={Home} />
          <Route path="/quiz/:quizId" component={Quiz} />
          <Route path="/report/:attemptId" component={Report} />
          <Route path="/corsi-on-demand" component={CorsiOnDemand} />
          <Route path="/corsi-on-demand/:courseId" component={CorsoOnDemand} />
          <Route path="/live-session/:sessionId" component={LiveSession} />
        </>
      )}
      <Route path="/page/:slug" component={DynamicContentPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <HelmetProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <CookieBanner />
          <FeedbackDialog />
          <Router />
        </TooltipProvider>
      </QueryClientProvider>
    </HelmetProvider>
  );
}

export default App;
