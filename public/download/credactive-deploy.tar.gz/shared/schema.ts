import { sql, relations } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  boolean,
  uuid,
  serial,
  unique,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique().notNull(),
  password: varchar("password"), // Hashed password for email/password auth (null for social login)
  authProvider: varchar("auth_provider", { length: 20 }).default("local"), // local, google, apple
  passwordResetToken: varchar("password_reset_token"),
  passwordResetExpires: timestamp("password_reset_expires"),
  emailVerified: boolean("email_verified").default(false),
  verificationCode: varchar("verification_code", { length: 6 }),
  verificationCodeExpires: timestamp("verification_code_expires"),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  dateOfBirth: timestamp("date_of_birth"),
  gender: varchar("gender", { length: 50 }), // male, female, other, prefer_not_to_say
  phone: varchar("phone", { length: 50 }),
  profession: varchar("profession", { length: 100 }),
  education: varchar("education", { length: 100 }),
  company: varchar("company", { length: 200 }),
  addressStreet: varchar("address_street", { length: 200 }),
  addressCity: varchar("address_city", { length: 100 }),
  addressPostalCode: varchar("address_postal_code", { length: 20 }),
  addressProvince: varchar("address_province", { length: 100 }),
  addressCountry: varchar("address_country", { length: 100 }),
  newsletterConsent: boolean("newsletter_consent").default(false),
  profileImageUrl: varchar("profile_image_url"),
  stripeCustomerId: varchar("stripe_customer_id"),
  stripeSubscriptionId: varchar("stripe_subscription_id"),
  isPremium: boolean("is_premium").default(false),
  subscriptionTier: varchar("subscription_tier", { length: 20 }).default("free"), // free, premium, premium_plus
  isAdmin: boolean("is_admin").default(false),
  language: varchar("language", { length: 2 }), // it, en, es, fr
  // Gamification fields
  nickname: varchar("nickname", { length: 50 }), // Display name for leaderboards
  totalPoints: integer("total_points").default(0),
  level: integer("level").default(1),
  currentStreak: integer("current_streak").default(0),
  longestStreak: integer("longest_streak").default(0),
  lastActivityDate: timestamp("last_activity_date"),
  // Virtual wallet
  credits: integer("credits").default(0),
  // Corporate agreement fields
  companyName: varchar("company_name", { length: 200 }),
  corporateAgreementId: uuid("corporate_agreement_id"),
  // Coupon tracking
  couponCode: varchar("coupon_code", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Quiz categories
export const categories = pgTable("categories", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 100 }).notNull(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  description: text("description"),
  icon: varchar("icon", { length: 50 }),
  color: varchar("color", { length: 20 }),
  isPremium: boolean("is_premium").default(true),
  isFeatured: boolean("is_featured").default(false),
  isPinned: boolean("is_pinned").default(false), // Pinned categories always appear in first 12 on home
  sortOrder: integer("sort_order").default(0),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Quizzes
export const quizzes = pgTable("quizzes", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  categoryId: uuid("category_id").notNull().references(() => categories.id),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description"),
  duration: integer("duration").notNull(), // in minutes
  difficulty: varchar("difficulty", { length: 20 }).notNull(), // beginner, intermediate, advanced, expert
  isPremium: boolean("is_premium").default(true),
  isActive: boolean("is_active").default(true),
  maxQuestionsPerAttempt: integer("max_questions_per_attempt"), // Optional: limit number of questions shown per attempt (null = all questions)
  documentPdfUrl: text("document_pdf_url"), // Optional: PDF document for AI question generation
  visibilityType: varchar("visibility_type", { length: 20 }).default("public"), // public, corporate_exclusive
  createdAt: timestamp("created_at").defaultNow(),
});

// Quiz corporate access mapping
export const quizCorporateAccess = pgTable("quiz_corporate_access", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  quizId: uuid("quiz_id").notNull().references(() => quizzes.id, { onDelete: 'cascade' }),
  corporateAgreementId: uuid("corporate_agreement_id").notNull().references(() => corporateAgreements.id, { onDelete: 'cascade' }),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  uniqueQuizAgreement: unique().on(table.quizId, table.corporateAgreementId),
}));

// Quiz questions
export const questions = pgTable("questions", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  quizId: uuid("quiz_id").notNull().references(() => quizzes.id),
  question: text("question").notNull(),
  imageUrl: text("image_url"), // Optional image for the question
  options: jsonb("options").notNull(), // Array of option objects {label, text, explanation}
  correctAnswer: text("correct_answer"), // Legacy: single correct answer (for backward compatibility)
  correctAnswers: jsonb("correct_answers"), // Array of correct answer labels for multiple-choice: ["A", "C"]
  explanation: text("explanation"),
  explanationAudioUrl: text("explanation_audio_url"), // TTS audio URL for the explanation
  category: varchar("category", { length: 100 }),
  domain: varchar("domain", { length: 200 }), // CISSP domain or topic hint
  language: varchar("language", { length: 5 }).default('it'), // Original language of the question (it, en, es, fr)
  createdAt: timestamp("created_at").defaultNow(),
});

// Quiz question generation jobs
export const quizGenerationJobs = pgTable("quiz_generation_jobs", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  quizId: uuid("quiz_id").notNull().references(() => quizzes.id),
  requestedCount: integer("requested_count").notNull(), // Number of questions requested
  generatedCount: integer("generated_count").default(0), // Number successfully generated
  status: varchar("status", { length: 20 }).notNull().default("pending"), // pending, processing, completed, failed
  error: text("error"), // Error message if failed
  difficulty: varchar("difficulty", { length: 20 }), // beginner, intermediate, advanced, expert
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

// User quiz attempts
export const userQuizAttempts = pgTable("user_quiz_attempts", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  quizId: uuid("quiz_id").notNull().references(() => quizzes.id),
  score: integer("score").notNull(), // percentage
  correctAnswers: integer("correct_answers").notNull(),
  totalQuestions: integer("total_questions").notNull(),
  timeSpent: integer("time_spent").notNull(), // in seconds
  answers: jsonb("answers").notNull(), // Array of {questionId, answer, isCorrect}
  pointsEarned: integer("points_earned").default(0), // Points earned in this attempt
  completedAt: timestamp("completed_at").defaultNow(),
});

// User progress tracking
export const userProgress = pgTable("user_progress", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  categoryId: uuid("category_id").notNull().references(() => categories.id),
  quizzesCompleted: integer("quizzes_completed").default(0),
  averageScore: integer("average_score").default(0),
  totalTimeSpent: integer("total_time_spent").default(0), // in seconds
  lastAttemptAt: timestamp("last_attempt_at"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Quiz reports
export const quizReports = pgTable("quiz_reports", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  attemptId: uuid("attempt_id").notNull().references(() => userQuizAttempts.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  quizId: uuid("quiz_id").notNull().references(() => quizzes.id),
  reportData: jsonb("report_data").notNull(), // Full report with analysis
  weakAreas: jsonb("weak_areas"), // Array of topics to improve
  strengths: jsonb("strengths"), // Array of strong topics
  recommendations: text("recommendations"),
  emailSent: boolean("email_sent").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Live courses
export const liveCourses = pgTable("live_courses", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  quizId: uuid("quiz_id").notNull().references(() => quizzes.id),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description"),
  objectives: text("objectives"), // Course objectives (long description)
  programModules: jsonb("program_modules"), // Structured array: [{moduleTitle, hours, topics}]
  cosaInclude: jsonb("cosa_include"), // Array of included items (strings)
  instructor: varchar("instructor", { length: 200 }), // Course instructor/teacher
  duration: varchar("duration", { length: 100 }), // Course duration (e.g., "12 ore", "2 giorni")
  language: varchar("language", { length: 10 }).notNull().default('it'), // Course language: it, en, es
  price: integer("price").notNull(), // Price in cents (e.g., 9000 for €90)
  stripeProductId: varchar("stripe_product_id"),
  stripePriceId: varchar("stripe_price_id"),
  isActive: boolean("is_active").default(true),
  visibilityType: varchar("visibility_type", { length: 20 }).default("public"), // public, corporate_exclusive
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Live course corporate access mapping
export const liveCourseCorporateAccess = pgTable("live_course_corporate_access", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  liveCourseId: uuid("live_course_id").notNull().references(() => liveCourses.id, { onDelete: 'cascade' }),
  corporateAgreementId: uuid("corporate_agreement_id").notNull().references(() => corporateAgreements.id, { onDelete: 'cascade' }),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  uniqueCourseAgreement: unique().on(table.liveCourseId, table.corporateAgreementId),
}));

// Live course sessions (dates)
export const liveCourseSessions = pgTable("live_course_sessions", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  courseId: uuid("course_id").notNull().references(() => liveCourses.id),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  capacity: integer("capacity").default(30),
  enrolled: integer("enrolled").default(0),
  status: varchar("status", { length: 20 }).default("available"), // available, full, completed, cancelled
  createdAt: timestamp("created_at").defaultNow(),
});

// Live course enrollments
export const liveCourseEnrollments = pgTable("live_course_enrollments", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  courseId: uuid("course_id").notNull().references(() => liveCourses.id),
  sessionId: uuid("session_id").notNull().references(() => liveCourseSessions.id),
  stripePaymentIntentId: varchar("stripe_payment_intent_id"),
  amountPaid: integer("amount_paid").notNull(), // Amount in cents
  status: varchar("status", { length: 20 }).default("pending"), // pending, confirmed, cancelled
  enrolledAt: timestamp("enrolled_at").defaultNow(),
});

// Live streaming sessions (active live sessions with video streaming)
export const liveStreamingSessions = pgTable("live_streaming_sessions", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: uuid("session_id").notNull().references(() => liveCourseSessions.id),
  streamUrl: text("stream_url").notNull(), // YouTube Live, Zoom, Google Meet, etc.
  title: text("title").notNull(), // Session title
  isActive: boolean("is_active").default(false),
  startedAt: timestamp("started_at"),
  endedAt: timestamp("ended_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Live streaming chat messages
export const liveStreamingMessages = pgTable("live_streaming_messages", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  streamingSessionId: uuid("streaming_session_id").notNull().references(() => liveStreamingSessions.id, { onDelete: 'cascade' }),
  userId: varchar("user_id").notNull().references(() => users.id),
  userName: varchar("user_name", { length: 200 }).notNull(), // Cached for performance
  message: text("message").notNull(),
  isAdminMessage: boolean("is_admin_message").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Live streaming polls/quiz (interactive questions during live)
export const liveStreamingPolls = pgTable("live_streaming_polls", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  streamingSessionId: uuid("streaming_session_id").notNull().references(() => liveStreamingSessions.id, { onDelete: 'cascade' }),
  question: text("question").notNull(),
  options: jsonb("options").notNull(), // Array of {label: string, text: string}
  correctAnswer: varchar("correct_answer", { length: 10 }), // null for polls, set for quiz questions
  pollType: varchar("poll_type", { length: 20 }).default("poll"), // poll, quiz
  showResults: boolean("show_results").default(false), // Show results to participants
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Live streaming poll responses
export const liveStreamingPollResponses = pgTable("live_streaming_poll_responses", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  pollId: uuid("poll_id").notNull().references(() => liveStreamingPolls.id, { onDelete: 'cascade' }),
  userId: varchar("user_id").notNull().references(() => users.id),
  selectedOption: varchar("selected_option", { length: 10 }).notNull(),
  isCorrect: boolean("is_correct"), // Set if poll is a quiz question
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  uniqueUserPoll: unique().on(table.pollId, table.userId),
}));

// Content pages (CMS for static pages)
export const contentPages = pgTable("content_pages", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  slug: varchar("slug", { length: 100 }).notNull().unique(), // e.g., "privacy", "terms", "about", "contact"
  title: varchar("title", { length: 200 }).notNull(),
  content: text("content").notNull(), // HTML content (sanitized)
  placement: varchar("placement", { length: 20 }).default("none"), // 'header', 'footer', 'none'
  isPublished: boolean("is_published").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// On-demand courses
export const onDemandCourses = pgTable("on_demand_courses", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description"),
  program: text("program"), // Course syllabus/program description
  categoryId: uuid("category_id").notNull().references(() => categories.id), // Required: link to quiz category
  instructor: varchar("instructor", { length: 200 }),
  difficulty: varchar("difficulty", { length: 20 }), // beginner, intermediate, advanced, expert
  duration: varchar("duration", { length: 100 }), // Total course duration estimate
  thumbnailUrl: text("thumbnail_url"), // Course thumbnail image
  isPremiumPlus: boolean("is_premium_plus").default(true), // Requires Premium Plus subscription
  isActive: boolean("is_active").default(true),
  sortOrder: integer("sort_order").default(0),
  visibilityType: varchar("visibility_type", { length: 20 }).default("public"), // public, corporate_exclusive
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// On-demand course corporate access mapping
export const onDemandCourseCorporateAccess = pgTable("on_demand_course_corporate_access", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  onDemandCourseId: uuid("on_demand_course_id").notNull().references(() => onDemandCourses.id, { onDelete: 'cascade' }),
  corporateAgreementId: uuid("corporate_agreement_id").notNull().references(() => corporateAgreements.id, { onDelete: 'cascade' }),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  uniqueCourseAgreement: unique().on(table.onDemandCourseId, table.corporateAgreementId),
}));

// Course videos
export const courseVideos = pgTable("course_videos", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  courseId: uuid("course_id").notNull().references(() => onDemandCourses.id),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description"),
  videoUrl: text("video_url").notNull(), // URL to video (YouTube, Vimeo, or uploaded)
  duration: integer("duration"), // Duration in seconds
  sortOrder: integer("sort_order").notNull().default(0), // Order of video in course
  thumbnailUrl: text("thumbnail_url"),
  requiresQuiz: boolean("requires_quiz").default(true), // Must answer questions to unlock next video
  createdAt: timestamp("created_at").defaultNow(),
});

// Video quiz questions (to unlock next video)
export const videoQuestions = pgTable("video_questions", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  videoId: uuid("video_id").notNull().references(() => courseVideos.id),
  question: text("question").notNull(),
  options: jsonb("options").notNull(), // Array of {label, text}
  correctAnswer: varchar("correct_answer", { length: 10 }).notNull(), // e.g., "A", "B", "C", "D"
  explanation: text("explanation"),
  sortOrder: integer("sort_order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Course quiz questions (at the end of the course, without video dependency)
export const courseQuestions = pgTable("course_questions", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  courseId: uuid("course_id").notNull().references(() => onDemandCourses.id),
  question: text("question").notNull(),
  options: jsonb("options").notNull(), // Array of {label, text}
  correctAnswer: varchar("correct_answer", { length: 10 }).notNull(), // e.g., "A", "B", "C", "D"
  explanation: text("explanation"),
  sortOrder: integer("sort_order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// User video progress tracking
export const userVideoProgress = pgTable("user_video_progress", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  courseId: uuid("course_id").notNull().references(() => onDemandCourses.id),
  videoId: uuid("video_id").notNull().references(() => courseVideos.id),
  completed: boolean("completed").default(false),
  quizPassed: boolean("quiz_passed").default(false), // Passed the quiz to unlock next video
  watchedSeconds: integer("watched_seconds").default(0), // Track progress within video
  lastWatchedAt: timestamp("last_watched_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

// Badges - Available badges in the system
export const badges = pgTable("badges", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 100 }).notNull(),
  description: text("description"),
  icon: varchar("icon", { length: 50 }), // Icon name or emoji
  color: varchar("color", { length: 20 }), // Badge color
  category: varchar("category", { length: 50 }), // quiz, streak, achievement, special
  requirement: text("requirement"), // Description of how to earn it
  points: integer("points").default(0), // Points awarded when earned
  isActive: boolean("is_active").default(true),
  sortOrder: integer("sort_order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// User badges - Badges earned by users
export const userBadges = pgTable("user_badges", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  badgeId: uuid("badge_id").notNull().references(() => badges.id),
  earnedAt: timestamp("earned_at").defaultNow(),
});

// Achievements - Available achievements in the system
export const achievements = pgTable("achievements", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 100 }).notNull(),
  description: text("description"),
  icon: varchar("icon", { length: 50 }), // Icon name or emoji
  category: varchar("category", { length: 50 }), // completion, mastery, dedication, social
  tier: varchar("tier", { length: 20 }).default("bronze"), // bronze, silver, gold, platinum
  requirement: jsonb("requirement"), // {type, target, progress} e.g., {type: "quizzes_completed", target: 10}
  points: integer("points").default(0), // Points awarded when unlocked
  badgeId: uuid("badge_id").references(() => badges.id), // Optional linked badge
  isActive: boolean("is_active").default(true),
  sortOrder: integer("sort_order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// User achievements - Achievements earned by users
export const userAchievements = pgTable("user_achievements", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  achievementId: uuid("achievement_id").notNull().references(() => achievements.id),
  progress: integer("progress").default(0), // Current progress towards achievement
  isUnlocked: boolean("is_unlocked").default(false),
  unlockedAt: timestamp("unlocked_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Daily challenges
export const dailyChallenges = pgTable("daily_challenges", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  date: timestamp("date").notNull(), // The date this challenge is for
  quizId: uuid("quiz_id").notNull().references(() => quizzes.id),
  categoryId: uuid("category_id").notNull().references(() => categories.id),
  questionCount: integer("question_count").default(5), // Number of questions in daily challenge
  points: integer("points").default(50), // Bonus points for completing
  expiresAt: timestamp("expires_at").notNull(), // When this challenge expires
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// User daily challenge completions
export const userDailyChallenges = pgTable("user_daily_challenges", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  challengeId: uuid("challenge_id").notNull().references(() => dailyChallenges.id),
  attemptId: uuid("attempt_id").references(() => userQuizAttempts.id), // Link to quiz attempt
  score: integer("score").notNull(), // Percentage score
  pointsEarned: integer("points_earned").default(0),
  completed: boolean("completed").default(false),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// User certificates
export const userCertificates = pgTable("user_certificates", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  categoryId: uuid("category_id").references(() => categories.id),
  quizId: uuid("quiz_id").references(() => quizzes.id),
  certificateType: varchar("certificate_type", { length: 50 }).notNull(), // quiz_completion, category_mastery, course_completion
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description"),
  score: integer("score"), // If applicable (e.g., quiz score)
  pdfUrl: text("pdf_url"), // URL to generated PDF certificate
  verificationCode: varchar("verification_code", { length: 50 }).unique(), // Unique code for verification
  isPublic: boolean("is_public").default(false), // If user wants to share publicly
  metadata: jsonb("metadata"), // Additional data (quiz details, stats, etc.)
  issuedAt: timestamp("issued_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Leaderboard entries (materialized view / cache table for performance)
export const leaderboard = pgTable("leaderboard", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  categoryId: uuid("category_id").references(() => categories.id), // null = global leaderboard
  rank: integer("rank").notNull(),
  points: integer("points").notNull(),
  quizzesCompleted: integer("quizzes_completed").default(0),
  averageScore: integer("average_score").default(0),
  period: varchar("period", { length: 20 }).default("all_time"), // all_time, monthly, weekly
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Activity log for tracking user actions and awarding points
export const activityLog = pgTable("activity_log", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  activityType: varchar("activity_type", { length: 50 }).notNull(), // quiz_completed, streak_maintained, badge_earned, etc.
  points: integer("points").default(0),
  metadata: jsonb("metadata"), // Additional context about the activity
  createdAt: timestamp("created_at").defaultNow(),
});

// Corporate agreements for company-wide premium access
export const corporateAgreements = pgTable("corporate_agreements", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  companyName: varchar("company_name", { length: 200 }).notNull(),
  emailDomain: varchar("email_domain", { length: 100 }), // e.g., "@company.com" (nullable for promo code only)
  promoCode: varchar("promo_code", { length: 50 }).unique(), // Alternative to email domain
  tier: varchar("tier", { length: 20 }).notNull().default("premium_plus"), // premium_plus
  isActive: boolean("is_active").default(true),
  maxUsers: integer("max_users"), // Optional limit on number of users
  currentUsers: integer("current_users").default(0), // Current number of users using this agreement
  notes: text("notes"), // Internal notes about the agreement
  // B2B fields
  adminUserId: varchar("admin_user_id").references(() => users.id), // Corporate admin user
  companyEmail: varchar("company_email", { length: 200 }),
  companyPhone: varchar("company_phone", { length: 50 }),
  vatNumber: varchar("vat_number", { length: 100 }), // Partita IVA
  billingAddress: text("billing_address"),
  contractStartDate: timestamp("contract_start_date"),
  contractEndDate: timestamp("contract_end_date"),
  licensesOwned: integer("licenses_owned").default(0), // Total licenses purchased
  licensesUsed: integer("licenses_used").default(0), // Licenses currently in use
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Corporate invites for onboarding employees
export const corporateInvites = pgTable("corporate_invites", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  corporateAgreementId: uuid("corporate_agreement_id").notNull().references(() => corporateAgreements.id),
  email: varchar("email", { length: 200 }).notNull(),
  invitedBy: varchar("invited_by").notNull().references(() => users.id), // Admin who sent invite
  status: varchar("status", { length: 20 }).default("pending"), // pending, accepted, expired
  token: varchar("token", { length: 100 }).unique().notNull(), // Unique invite token
  expiresAt: timestamp("expires_at").notNull(),
  acceptedAt: timestamp("accepted_at"),
  createdAt: timestamp("created_at").defaultNow(),
  // Course-specific invite fields (optional)
  targetCourseType: varchar("target_course_type", { length: 20 }), // 'live' | 'on_demand' | null
  targetCourseId: varchar("target_course_id", { length: 100 }), // Course ID if invite is for specific course
  targetCourseName: varchar("target_course_name", { length: 300 }), // Course name for email (avoids JOIN)
});

// Corporate license packages purchased by companies
export const corporateLicenses = pgTable("corporate_licenses", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  corporateAgreementId: uuid("corporate_agreement_id").notNull().references(() => corporateAgreements.id),
  packageType: varchar("package_type", { length: 50 }).notNull(), // small_10, medium_50, large_100, enterprise_500
  licenseCount: integer("license_count").notNull(), // Number of licenses in package
  pricePerLicense: integer("price_per_license").notNull(), // Price in cents
  totalPrice: integer("total_price").notNull(), // Total price in cents
  currency: varchar("currency", { length: 3 }).default("EUR"),
  billingInterval: varchar("billing_interval", { length: 20 }).default("year"), // month, year
  stripePaymentIntentId: varchar("stripe_payment_intent_id"),
  stripeInvoiceId: varchar("stripe_invoice_id"),
  status: varchar("status", { length: 20 }).default("active"), // active, expired, cancelled
  purchasedAt: timestamp("purchased_at").defaultNow(),
  expiresAt: timestamp("expires_at"),
});

// Corporate course assignments - courses available to all employees of a company
export const corporateCourseAssignments = pgTable("corporate_course_assignments", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  corporateAgreementId: uuid("corporate_agreement_id").notNull().references(() => corporateAgreements.id, { onDelete: 'cascade' }),
  courseType: varchar("course_type", { length: 20 }).notNull(), // 'live' | 'on_demand'
  courseId: varchar("course_id", { length: 100 }).notNull(), // ID of the live course or quiz
  courseName: varchar("course_name", { length: 300 }).notNull(), // Name for display
  assignedBy: varchar("assigned_by").notNull().references(() => users.id), // Admin who assigned
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  uniqueCourseAssignment: unique().on(table.corporateAgreementId, table.courseType, table.courseId),
}));

// Application settings for API keys and configuration
export const settings = pgTable("settings", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  key: varchar("key", { length: 100 }).unique().notNull(), // e.g., "OPENAI_API_KEY", "STRIPE_SECRET_KEY"
  value: text("value"), // The API key or configuration value
  description: text("description"), // Human-readable description
  category: varchar("category", { length: 50 }).default("api_keys"), // api_keys, general, etc.
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ one, many }) => ({
  quizAttempts: many(userQuizAttempts),
  progress: many(userProgress),
  badges: many(userBadges),
  achievements: many(userAchievements),
  certificates: many(userCertificates),
  dailyChallenges: many(userDailyChallenges),
  activityLog: many(activityLog),
  corporateAgreement: one(corporateAgreements, {
    fields: [users.corporateAgreementId],
    references: [corporateAgreements.id],
  }),
}));

export const categoriesRelations = relations(categories, ({ many }) => ({
  quizzes: many(quizzes),
  userProgress: many(userProgress),
}));

export const quizzesRelations = relations(quizzes, ({ one, many }) => ({
  category: one(categories, {
    fields: [quizzes.categoryId],
    references: [categories.id],
  }),
  questions: many(questions),
  attempts: many(userQuizAttempts),
}));

export const questionsRelations = relations(questions, ({ one }) => ({
  quiz: one(quizzes, {
    fields: [questions.quizId],
    references: [quizzes.id],
  }),
}));

export const userQuizAttemptsRelations = relations(userQuizAttempts, ({ one }) => ({
  user: one(users, {
    fields: [userQuizAttempts.userId],
    references: [users.id],
  }),
  quiz: one(quizzes, {
    fields: [userQuizAttempts.quizId],
    references: [quizzes.id],
  }),
}));

export const userProgressRelations = relations(userProgress, ({ one }) => ({
  user: one(users, {
    fields: [userProgress.userId],
    references: [users.id],
  }),
  category: one(categories, {
    fields: [userProgress.categoryId],
    references: [categories.id],
  }),
}));

export const quizReportsRelations = relations(quizReports, ({ one }) => ({
  user: one(users, {
    fields: [quizReports.userId],
    references: [users.id],
  }),
  quiz: one(quizzes, {
    fields: [quizReports.quizId],
    references: [quizzes.id],
  }),
  attempt: one(userQuizAttempts, {
    fields: [quizReports.attemptId],
    references: [userQuizAttempts.id],
  }),
}));

export const liveCoursesRelations = relations(liveCourses, ({ one, many }) => ({
  quiz: one(quizzes, {
    fields: [liveCourses.quizId],
    references: [quizzes.id],
  }),
  sessions: many(liveCourseSessions),
  enrollments: many(liveCourseEnrollments),
}));

export const liveCourseSessionsRelations = relations(liveCourseSessions, ({ one, many }) => ({
  course: one(liveCourses, {
    fields: [liveCourseSessions.courseId],
    references: [liveCourses.id],
  }),
  enrollments: many(liveCourseEnrollments),
}));

export const liveCourseEnrollmentsRelations = relations(liveCourseEnrollments, ({ one }) => ({
  user: one(users, {
    fields: [liveCourseEnrollments.userId],
    references: [users.id],
  }),
  course: one(liveCourses, {
    fields: [liveCourseEnrollments.courseId],
    references: [liveCourses.id],
  }),
  session: one(liveCourseSessions, {
    fields: [liveCourseEnrollments.sessionId],
    references: [liveCourseSessions.id],
  }),
}));

export const onDemandCoursesRelations = relations(onDemandCourses, ({ one, many }) => ({
  category: one(categories, {
    fields: [onDemandCourses.categoryId],
    references: [categories.id],
  }),
  videos: many(courseVideos),
  questions: many(courseQuestions),
}));

export const courseVideosRelations = relations(courseVideos, ({ one, many }) => ({
  course: one(onDemandCourses, {
    fields: [courseVideos.courseId],
    references: [onDemandCourses.id],
  }),
  questions: many(videoQuestions),
  progress: many(userVideoProgress),
}));

export const videoQuestionsRelations = relations(videoQuestions, ({ one }) => ({
  video: one(courseVideos, {
    fields: [videoQuestions.videoId],
    references: [courseVideos.id],
  }),
}));

export const courseQuestionsRelations = relations(courseQuestions, ({ one }) => ({
  course: one(onDemandCourses, {
    fields: [courseQuestions.courseId],
    references: [onDemandCourses.id],
  }),
}));

export const userVideoProgressRelations = relations(userVideoProgress, ({ one }) => ({
  user: one(users, {
    fields: [userVideoProgress.userId],
    references: [users.id],
  }),
  course: one(onDemandCourses, {
    fields: [userVideoProgress.courseId],
    references: [onDemandCourses.id],
  }),
  video: one(courseVideos, {
    fields: [userVideoProgress.videoId],
    references: [courseVideos.id],
  }),
}));

export const badgesRelations = relations(badges, ({ many }) => ({
  userBadges: many(userBadges),
  achievements: many(achievements),
}));

export const userBadgesRelations = relations(userBadges, ({ one }) => ({
  user: one(users, {
    fields: [userBadges.userId],
    references: [users.id],
  }),
  badge: one(badges, {
    fields: [userBadges.badgeId],
    references: [badges.id],
  }),
}));

export const achievementsRelations = relations(achievements, ({ one, many }) => ({
  badge: one(badges, {
    fields: [achievements.badgeId],
    references: [badges.id],
  }),
  userAchievements: many(userAchievements),
}));

export const userAchievementsRelations = relations(userAchievements, ({ one }) => ({
  user: one(users, {
    fields: [userAchievements.userId],
    references: [users.id],
  }),
  achievement: one(achievements, {
    fields: [userAchievements.achievementId],
    references: [achievements.id],
  }),
}));

export const dailyChallengesRelations = relations(dailyChallenges, ({ one, many }) => ({
  quiz: one(quizzes, {
    fields: [dailyChallenges.quizId],
    references: [quizzes.id],
  }),
  category: one(categories, {
    fields: [dailyChallenges.categoryId],
    references: [categories.id],
  }),
  completions: many(userDailyChallenges),
}));

export const userDailyChallengesRelations = relations(userDailyChallenges, ({ one }) => ({
  user: one(users, {
    fields: [userDailyChallenges.userId],
    references: [users.id],
  }),
  challenge: one(dailyChallenges, {
    fields: [userDailyChallenges.challengeId],
    references: [dailyChallenges.id],
  }),
  attempt: one(userQuizAttempts, {
    fields: [userDailyChallenges.attemptId],
    references: [userQuizAttempts.id],
  }),
}));

export const userCertificatesRelations = relations(userCertificates, ({ one }) => ({
  user: one(users, {
    fields: [userCertificates.userId],
    references: [users.id],
  }),
  category: one(categories, {
    fields: [userCertificates.categoryId],
    references: [categories.id],
  }),
  quiz: one(quizzes, {
    fields: [userCertificates.quizId],
    references: [quizzes.id],
  }),
}));

export const leaderboardRelations = relations(leaderboard, ({ one }) => ({
  user: one(users, {
    fields: [leaderboard.userId],
    references: [users.id],
  }),
  category: one(categories, {
    fields: [leaderboard.categoryId],
    references: [categories.id],
  }),
}));

export const activityLogRelations = relations(activityLog, ({ one }) => ({
  user: one(users, {
    fields: [activityLog.userId],
    references: [users.id],
  }),
}));

export const corporateAgreementsRelations = relations(corporateAgreements, ({ one, many }) => ({
  users: many(users),
  admin: one(users, {
    fields: [corporateAgreements.adminUserId],
    references: [users.id],
  }),
  invites: many(corporateInvites),
  licenses: many(corporateLicenses),
  courseAssignments: many(corporateCourseAssignments),
}));

export const corporateInvitesRelations = relations(corporateInvites, ({ one }) => ({
  corporateAgreement: one(corporateAgreements, {
    fields: [corporateInvites.corporateAgreementId],
    references: [corporateAgreements.id],
  }),
  inviter: one(users, {
    fields: [corporateInvites.invitedBy],
    references: [users.id],
  }),
}));

export const corporateLicensesRelations = relations(corporateLicenses, ({ one }) => ({
  corporateAgreement: one(corporateAgreements, {
    fields: [corporateLicenses.corporateAgreementId],
    references: [corporateAgreements.id],
  }),
}));

export const corporateCourseAssignmentsRelations = relations(corporateCourseAssignments, ({ one }) => ({
  corporateAgreement: one(corporateAgreements, {
    fields: [corporateCourseAssignments.corporateAgreementId],
    references: [corporateAgreements.id],
  }),
  assignedByUser: one(users, {
    fields: [corporateCourseAssignments.assignedBy],
    references: [users.id],
  }),
}));

// Types
export type User = typeof users.$inferSelect;
export type UpsertUser = typeof users.$inferInsert;
export type Category = typeof categories.$inferSelect;
export type Quiz = typeof quizzes.$inferSelect;
export type Question = typeof questions.$inferSelect;
export type QuizGenerationJob = typeof quizGenerationJobs.$inferSelect;
export type UserQuizAttempt = typeof userQuizAttempts.$inferSelect;
export type UserProgress = typeof userProgress.$inferSelect;
export type QuizReport = typeof quizReports.$inferSelect;
export type LiveCourse = typeof liveCourses.$inferSelect;
export type LiveCourseSession = typeof liveCourseSessions.$inferSelect;
export type LiveCourseEnrollment = typeof liveCourseEnrollments.$inferSelect;
export type LiveStreamingSession = typeof liveStreamingSessions.$inferSelect;
export type LiveStreamingMessage = typeof liveStreamingMessages.$inferSelect;
export type LiveStreamingPoll = typeof liveStreamingPolls.$inferSelect;
export type LiveStreamingPollResponse = typeof liveStreamingPollResponses.$inferSelect;
export type ContentPage = typeof contentPages.$inferSelect;
export type OnDemandCourse = typeof onDemandCourses.$inferSelect;
export type CourseVideo = typeof courseVideos.$inferSelect;
export type VideoQuestion = typeof videoQuestions.$inferSelect;
export type CourseQuestion = typeof courseQuestions.$inferSelect;
export type UserVideoProgress = typeof userVideoProgress.$inferSelect;
export type Badge = typeof badges.$inferSelect;
export type UserBadge = typeof userBadges.$inferSelect;
export type Achievement = typeof achievements.$inferSelect;
export type UserAchievement = typeof userAchievements.$inferSelect;
export type DailyChallenge = typeof dailyChallenges.$inferSelect;
export type UserDailyChallenge = typeof userDailyChallenges.$inferSelect;
export type UserCertificate = typeof userCertificates.$inferSelect;
export type Leaderboard = typeof leaderboard.$inferSelect;
export type ActivityLog = typeof activityLog.$inferSelect;
export type CorporateAgreement = typeof corporateAgreements.$inferSelect;
export type CorporateInvite = typeof corporateInvites.$inferSelect;
export type CorporateLicense = typeof corporateLicenses.$inferSelect;
export type Setting = typeof settings.$inferSelect;
export type QuizCorporateAccess = typeof quizCorporateAccess.$inferSelect;
export type LiveCourseCorporateAccess = typeof liveCourseCorporateAccess.$inferSelect;
export type OnDemandCourseCorporateAccess = typeof onDemandCourseCorporateAccess.$inferSelect;

// Insert schemas
export const insertCategorySchema = createInsertSchema(categories);
export const insertQuizSchema = createInsertSchema(quizzes);
export const insertQuestionSchema = createInsertSchema(questions);
export const insertQuizGenerationJobSchema = createInsertSchema(quizGenerationJobs).omit({ id: true, createdAt: true, completedAt: true });
export const insertUserQuizAttemptSchema = createInsertSchema(userQuizAttempts);
export const insertUserProgressSchema = createInsertSchema(userProgress);
export const insertQuizReportSchema = createInsertSchema(quizReports);
export const insertLiveCourseSchema = createInsertSchema(liveCourses).omit({ id: true, createdAt: true, updatedAt: true });
export const insertLiveCourseSessionSchema = createInsertSchema(liveCourseSessions).omit({ id: true, createdAt: true });
export const insertLiveCourseEnrollmentSchema = createInsertSchema(liveCourseEnrollments).omit({ id: true, enrolledAt: true });
export const insertLiveStreamingSessionSchema = createInsertSchema(liveStreamingSessions).omit({ id: true, createdAt: true });
export const insertLiveStreamingMessageSchema = createInsertSchema(liveStreamingMessages).omit({ id: true, createdAt: true });
export const insertLiveStreamingPollSchema = createInsertSchema(liveStreamingPolls).omit({ id: true, createdAt: true });
export const insertLiveStreamingPollResponseSchema = createInsertSchema(liveStreamingPollResponses).omit({ id: true, createdAt: true });
export const insertContentPageSchema = createInsertSchema(contentPages).omit({ id: true, createdAt: true, updatedAt: true });
export const updateContentPageSchema = createInsertSchema(contentPages).pick({ 
  title: true, 
  content: true, 
  isPublished: true 
}).partial();
export const insertOnDemandCourseSchema = createInsertSchema(onDemandCourses).omit({ id: true, createdAt: true, updatedAt: true });
export const insertCourseVideoSchema = createInsertSchema(courseVideos).omit({ id: true, createdAt: true });
export const insertVideoQuestionSchema = createInsertSchema(videoQuestions).omit({ id: true, createdAt: true });
export const insertCourseQuestionSchema = createInsertSchema(courseQuestions).omit({ id: true, createdAt: true });
export const insertUserVideoProgressSchema = createInsertSchema(userVideoProgress).omit({ id: true, lastWatchedAt: true, completedAt: true });
export const updateOnDemandCourseSchema = insertOnDemandCourseSchema.partial();
export const updateCourseVideoSchema = insertCourseVideoSchema.partial();
export const updateVideoQuestionSchema = insertVideoQuestionSchema.partial();
export const updateCourseQuestionSchema = insertCourseQuestionSchema.partial();
export const insertBadgeSchema = createInsertSchema(badges).omit({ id: true, createdAt: true });
export const insertUserBadgeSchema = createInsertSchema(userBadges).omit({ id: true, earnedAt: true });
export const insertAchievementSchema = createInsertSchema(achievements).omit({ id: true, createdAt: true });
export const insertUserAchievementSchema = createInsertSchema(userAchievements).omit({ id: true, createdAt: true, updatedAt: true });
export const insertDailyChallengeSchema = createInsertSchema(dailyChallenges).omit({ id: true, createdAt: true });
export const insertUserDailyChallengeSchema = createInsertSchema(userDailyChallenges).omit({ id: true, createdAt: true, completedAt: true });
export const insertUserCertificateSchema = createInsertSchema(userCertificates).omit({ id: true, createdAt: true, issuedAt: true });
export const insertLeaderboardSchema = createInsertSchema(leaderboard).omit({ id: true, updatedAt: true });
export const insertActivityLogSchema = createInsertSchema(activityLog).omit({ id: true, createdAt: true });
export const insertCorporateAgreementSchema = createInsertSchema(corporateAgreements).omit({ id: true, createdAt: true, updatedAt: true });
export const insertCorporateInviteSchema = createInsertSchema(corporateInvites).omit({ id: true, createdAt: true });
export const insertCorporateLicenseSchema = createInsertSchema(corporateLicenses).omit({ id: true });
export const insertCorporateCourseAssignmentSchema = createInsertSchema(corporateCourseAssignments).omit({ id: true, createdAt: true });
export const insertSettingSchema = createInsertSchema(settings).omit({ id: true, createdAt: true, updatedAt: true });
export const updateSettingSchema = insertSettingSchema.partial();
export const insertQuizCorporateAccessSchema = createInsertSchema(quizCorporateAccess).omit({ id: true, createdAt: true });
export const insertLiveCourseCorporateAccessSchema = createInsertSchema(liveCourseCorporateAccess).omit({ id: true, createdAt: true });
export const insertOnDemandCourseCorporateAccessSchema = createInsertSchema(onDemandCourseCorporateAccess).omit({ id: true, createdAt: true });

export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type InsertQuiz = z.infer<typeof insertQuizSchema>;
export type InsertQuestion = z.infer<typeof insertQuestionSchema>;
export type InsertQuizGenerationJob = z.infer<typeof insertQuizGenerationJobSchema>;
export type InsertUserQuizAttempt = z.infer<typeof insertUserQuizAttemptSchema>;
export type InsertUserProgress = z.infer<typeof insertUserProgressSchema>;
export type InsertQuizReport = z.infer<typeof insertQuizReportSchema>;
export type InsertLiveCourse = z.infer<typeof insertLiveCourseSchema>;
export type InsertLiveCourseSession = z.infer<typeof insertLiveCourseSessionSchema>;
export type InsertLiveCourseEnrollment = z.infer<typeof insertLiveCourseEnrollmentSchema>;
export type InsertLiveStreamingSession = z.infer<typeof insertLiveStreamingSessionSchema>;
export type InsertLiveStreamingMessage = z.infer<typeof insertLiveStreamingMessageSchema>;
export type InsertLiveStreamingPoll = z.infer<typeof insertLiveStreamingPollSchema>;
export type InsertLiveStreamingPollResponse = z.infer<typeof insertLiveStreamingPollResponseSchema>;
export type InsertContentPage = z.infer<typeof insertContentPageSchema>;
export type UpdateContentPage = z.infer<typeof updateContentPageSchema>;
export type InsertOnDemandCourse = z.infer<typeof insertOnDemandCourseSchema>;
export type InsertCourseVideo = z.infer<typeof insertCourseVideoSchema>;
export type InsertVideoQuestion = z.infer<typeof insertVideoQuestionSchema>;
export type InsertCourseQuestion = z.infer<typeof insertCourseQuestionSchema>;
export type InsertUserVideoProgress = z.infer<typeof insertUserVideoProgressSchema>;
export type InsertBadge = z.infer<typeof insertBadgeSchema>;
export type InsertUserBadge = z.infer<typeof insertUserBadgeSchema>;
export type InsertAchievement = z.infer<typeof insertAchievementSchema>;
export type InsertUserAchievement = z.infer<typeof insertUserAchievementSchema>;
export type InsertDailyChallenge = z.infer<typeof insertDailyChallengeSchema>;
export type InsertUserDailyChallenge = z.infer<typeof insertUserDailyChallengeSchema>;
export type InsertUserCertificate = z.infer<typeof insertUserCertificateSchema>;
export type InsertLeaderboard = z.infer<typeof insertLeaderboardSchema>;
export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type InsertCorporateAgreement = z.infer<typeof insertCorporateAgreementSchema>;
export type InsertCorporateInvite = z.infer<typeof insertCorporateInviteSchema>;
export type InsertCorporateLicense = z.infer<typeof insertCorporateLicenseSchema>;
export type InsertCorporateCourseAssignment = z.infer<typeof insertCorporateCourseAssignmentSchema>;
export type SelectCorporateCourseAssignment = typeof corporateCourseAssignments.$inferSelect;
export type InsertSetting = z.infer<typeof insertSettingSchema>;
export type UpdateSetting = z.infer<typeof updateSettingSchema>;

// Email Templates
export const emailTemplates = pgTable("email_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  code: varchar("code", { length: 50 }).unique().notNull(), // welcome, verification, password_reset, etc.
  name: varchar("name", { length: 100 }).notNull(),
  subject: varchar("subject", { length: 200 }).notNull(),
  htmlContent: text("html_content").notNull(),
  textContent: text("text_content"),
  variables: text("variables").array(), // Available variables like {{firstName}}, {{verificationCode}}, etc.
  description: text("description"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type EmailTemplate = typeof emailTemplates.$inferSelect;
export const insertEmailTemplateSchema = createInsertSchema(emailTemplates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertEmailTemplate = z.infer<typeof insertEmailTemplateSchema>;

// Subscription Plans
export const subscriptionPlans = pgTable("subscription_plans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 100 }).notNull(), // e.g., "Premium", "Premium Plus"
  description: text("description"), // AI-formatted bullet points of features
  price: integer("price").notNull(), // Price in cents (e.g., 9000 for €90)
  currency: varchar("currency", { length: 3 }).default("EUR"), // EUR, USD, etc.
  interval: varchar("interval", { length: 20 }).default("year"), // month, year
  isActive: boolean("is_active").default(true),
  sortOrder: integer("sort_order").default(0), // For display ordering
  features: text("features").array(), // Array of feature strings for display
  stripeEnabled: boolean("stripe_enabled").default(false), // Show Stripe payment button
  stripeProductId: varchar("stripe_product_id"), // Stripe Product ID (optional)
  stripePriceId: varchar("stripe_price_id"), // Stripe Price ID (optional)
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type SubscriptionPlan = typeof subscriptionPlans.$inferSelect;
export const insertSubscriptionPlanSchema = createInsertSchema(subscriptionPlans).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertSubscriptionPlan = z.infer<typeof insertSubscriptionPlanSchema>;

// Marketing Campaigns
export const marketingCampaigns = pgTable("marketing_campaigns", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 200 }).notNull(),
  subject: varchar("subject", { length: 200 }).notNull(),
  htmlContent: text("html_content").notNull(),
  textContent: text("text_content"),
  
  // Segmentation filters (JSON)
  targetFilters: jsonb("target_filters"), // {subscriptionTier: ["free"], profession: ["developer"], etc.}
  
  // Campaign metadata
  status: varchar("status", { length: 20 }).default("draft"), // draft, scheduled, sending, sent, failed
  scheduledAt: timestamp("scheduled_at"),
  sentAt: timestamp("sent_at"),
  
  // Statistics
  recipientsCount: integer("recipients_count").default(0),
  sentCount: integer("sent_count").default(0),
  failedCount: integer("failed_count").default(0),
  openedCount: integer("opened_count").default(0),
  clickedCount: integer("clicked_count").default(0),
  
  createdBy: varchar("created_by"), // Admin user ID
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type MarketingCampaign = typeof marketingCampaigns.$inferSelect;
export const insertMarketingCampaignSchema = createInsertSchema(marketingCampaigns).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertMarketingCampaign = z.infer<typeof insertMarketingCampaignSchema>;

// Marketing Templates (reusable email templates)
export const marketingTemplates = pgTable("marketing_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 200 }).notNull(),
  description: text("description"),
  category: varchar("category", { length: 50 }), // promotion, course_recommendation, newsletter, etc.
  
  subject: varchar("subject", { length: 200 }).notNull(),
  htmlContent: text("html_content").notNull(),
  textContent: text("text_content"),
  
  // Variables available in template
  variables: text("variables").array(), // ["{{firstName}}", "{{courseName}}", etc.]
  
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type MarketingTemplate = typeof marketingTemplates.$inferSelect;
export const insertMarketingTemplateSchema = createInsertSchema(marketingTemplates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertMarketingTemplate = z.infer<typeof insertMarketingTemplateSchema>;

// Campaign Recipients (track who received what)
export const campaignRecipients = pgTable("campaign_recipients", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  campaignId: varchar("campaign_id").notNull().references(() => marketingCampaigns.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  
  status: varchar("status", { length: 20 }).default("pending"), // pending, sent, failed, opened, clicked
  sentAt: timestamp("sent_at"),
  openedAt: timestamp("opened_at"),
  clickedAt: timestamp("clicked_at"),
  
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type CampaignRecipient = typeof campaignRecipients.$inferSelect;

// AI Scenario Conversations (post-answer interactive scenarios)
export const scenarioConversations = pgTable("scenario_conversations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  questionId: uuid("question_id").notNull().references(() => questions.id, { onDelete: "cascade" }),
  quizId: uuid("quiz_id").notNull().references(() => quizzes.id, { onDelete: "cascade" }),
  
  // Context for AI to generate relevant scenarios
  scenarioType: varchar("scenario_type", { length: 50 }).notNull(), // business_case, personal_development
  category: varchar("category", { length: 100 }), // GDPR, ISO27001, Insight Discovery, etc.
  userAnswer: varchar("user_answer", { length: 10 }), // A, B, C, D
  wasCorrect: boolean("was_correct").notNull(),
  
  // Scenario metadata
  scenarioTitle: text("scenario_title"), // e.g., "Data Breach Response Scenario"
  scenarioContext: text("scenario_context"), // Initial scenario description
  
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type ScenarioConversation = typeof scenarioConversations.$inferSelect;
export const insertScenarioConversationSchema = createInsertSchema(scenarioConversations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertScenarioConversation = z.infer<typeof insertScenarioConversationSchema>;

// AI Scenario Messages (conversation messages)
export const scenarioMessages = pgTable("scenario_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  conversationId: varchar("conversation_id").notNull().references(() => scenarioConversations.id, { onDelete: "cascade" }),
  
  role: varchar("role", { length: 20 }).notNull(), // user, assistant
  content: text("content").notNull(),
  
  createdAt: timestamp("created_at").defaultNow(),
});

export type ScenarioMessage = typeof scenarioMessages.$inferSelect;
export const insertScenarioMessageSchema = createInsertSchema(scenarioMessages).omit({
  id: true,
  createdAt: true,
});
export type InsertScenarioMessage = z.infer<typeof insertScenarioMessageSchema>;

// User Feedback (rating and comments)
export const userFeedback = pgTable("user_feedback", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }),
  rating: integer("rating").notNull(), // 1-5 stars
  comment: text("comment"),
  source: varchar("source", { length: 50 }), // popup, email, manual
  createdAt: timestamp("created_at").defaultNow(),
});

export type UserFeedback = typeof userFeedback.$inferSelect;
export const insertUserFeedbackSchema = createInsertSchema(userFeedback).omit({
  id: true,
  createdAt: true,
});
export type InsertUserFeedback = z.infer<typeof insertUserFeedbackSchema>;

// Extended types for API responses
export type QuizWithCount = Quiz & { questionCount: number };
